/* Builds PGN text from Chess Titans' move records. */
#pragma once
#include "san.h"

/* One move as stored by chess.exe (20 bytes). Ranks: index 0 = rank 8. */
typedef struct { int promo, fromFile, fromRank, toFile, toRank; } TitansMove;

typedef struct {
    char white[64], black[64], date[16], result[8], termination[96], difficulty[32];
} PgnInfo;

static int s_cat(char *dst, int pos, int cap, const char *s) {
    while (*s && pos < cap - 1) dst[pos++] = *s++;
    dst[pos] = 0;
    return pos;
}

static int s_num(char *dst, int pos, int cap, int v) {
    char t[12]; int n = 0;
    if (v == 0) t[n++] = '0';
    while (v > 0) { t[n++] = (char)('0' + v % 10); v /= 10; }
    while (n && pos < cap - 1) dst[pos++] = t[--n];
    dst[pos] = 0;
    return pos;
}

static char promo_letter(int code) {
    switch (code) { case 12: return 'Q'; case 11: return 'R'; case 10: return 'B'; case 9: return 'N'; }
    return 0;
}

/* Returns length written. *mateOut gets 1 if final position is checkmate,
   2 if stalemate, 0 otherwise. *badAt gets index of first move that could
   not be decoded (or -1). */
static int build_pgn(const TitansMove *mv, int count, PgnInfo *info, char *out, int cap,
                     int *mateOut, int *badAt) {
    Board b; board_init(&b);
    char moves[16384]; int mp = 0, col = 0;
    *badAt = -1; *mateOut = 0;
    for (int i = 0; i < count; i++) {
        const TitansMove *t = &mv[i];
        if (t->fromFile < 0 || t->fromFile > 7 || t->toFile < 0 || t->toFile > 7 ||
            t->fromRank < 0 || t->fromRank > 7 || t->toRank < 0 || t->toRank > 7) { *badAt = i; break; }
        Mv m = { (7 - t->fromRank) * 8 + t->fromFile, (7 - t->toRank) * 8 + t->toFile, promo_letter(t->promo) };
        if (!find_legal(&b, &m)) { *badAt = i; break; }
        char tok[24]; int tl = 0;
        if (b.white) { tl = s_num(tok, 0, sizeof tok, i / 2 + 1); tok[tl++] = '.'; tok[tl++] = ' '; tok[tl] = 0; }
        else if (i == 0) { tl = s_cat(tok, 0, sizeof tok, "1... "); }
        tl += san(&b, m, tok + tl);
        if (col + tl + 1 > 79) { mp = s_cat(moves, mp, sizeof moves, "\r\n"); col = 0; }
        else if (col) { mp = s_cat(moves, mp, sizeof moves, " "); col++; }
        mp = s_cat(moves, mp, sizeof moves, tok); col += tl;
        make_move(&b, m);
    }
    if (*badAt < 0) {
        Mv lm[256];
        if (!gen_legal(&b, lm)) *mateOut = in_check(&b, b.white) ? 1 : 2;
        if (*mateOut == 1) {
            s_cat(info->result, 0, sizeof info->result, b.white ? "0-1" : "1-0");
            if (!info->termination[0]) s_cat(info->termination, 0, sizeof info->termination, b.white ? "Black wins by checkmate." : "White wins by checkmate.");
        } else if (*mateOut == 2) {
            s_cat(info->result, 0, sizeof info->result, "1/2-1/2");
            if (!info->termination[0]) s_cat(info->termination, 0, sizeof info->termination, "Stalemate, the game is a draw.");
        }
    }
    if (!info->result[0]) s_cat(info->result, 0, sizeof info->result, "*");

    int p = 0;
    p = s_cat(out, p, cap, "[Event \"Chess Titans\"]\r\n[Site \"Chess Titans\"]\r\n[Date \"");
    p = s_cat(out, p, cap, info->date);
    p = s_cat(out, p, cap, "\"]\r\n[Round \"-\"]\r\n[White \"");
    p = s_cat(out, p, cap, info->white);
    p = s_cat(out, p, cap, "\"]\r\n[Black \"");
    p = s_cat(out, p, cap, info->black);
    p = s_cat(out, p, cap, "\"]\r\n[Result \"");
    p = s_cat(out, p, cap, info->result);
    p = s_cat(out, p, cap, "\"]\r\n");
    if (info->difficulty[0]) {
        p = s_cat(out, p, cap, "[Difficulty \"");
        p = s_cat(out, p, cap, info->difficulty);
        p = s_cat(out, p, cap, "\"]\r\n");
    }
    p = s_cat(out, p, cap, "[PlyCount \"");
    p = s_num(out, p, cap, *badAt < 0 ? count : *badAt);
    p = s_cat(out, p, cap, "\"]\r\n\r\n");
    p = s_cat(out, p, cap, moves);
    if (mp) p = s_cat(out, p, cap, " ");
    if (info->termination[0]) {
        p = s_cat(out, p, cap, "{");
        p = s_cat(out, p, cap, info->termination);
        p = s_cat(out, p, cap, "} ");
    }
    if (*badAt >= 0) p = s_cat(out, p, cap, "{Remaining moves could not be read.} ");
    p = s_cat(out, p, cap, info->result);
    p = s_cat(out, p, cap, "\r\n");
    return p;
}
