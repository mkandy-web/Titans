/* Minimal chess board used to turn Chess Titans' coordinate move list
   into standard PGN notation (SAN). No CRT dependencies. */
#pragma once

typedef struct {
    char sq[64];      /* index = rank*8+file, rank 0 = '1'. 'PNBRQK' white, 'pnbrqk' black, 0 empty */
    int  white;       /* 1 = white to move */
    int  ep;          /* en passant target square or -1 */
    int  castle;      /* bit0 K, bit1 Q, bit2 k, bit3 q */
} Board;

typedef struct { int from, to; char promo; } Mv;

static int is_white(char p) { return p >= 'A' && p <= 'Z'; }
static char up(char p) { return (p >= 'a' && p <= 'z') ? (char)(p - 32) : p; }

static void board_init(Board *b) {
    const char *back = "RNBQKBNR";
    for (int i = 0; i < 64; i++) b->sq[i] = 0;
    for (int f = 0; f < 8; f++) {
        b->sq[f] = back[f];
        b->sq[8 + f] = 'P';
        b->sq[48 + f] = 'p';
        b->sq[56 + f] = (char)(back[f] + 32);
    }
    b->white = 1; b->ep = -1; b->castle = 15;
}

static const int KN[8][2] = {{1,2},{2,1},{-1,2},{-2,1},{1,-2},{2,-1},{-1,-2},{-2,-1}};
static const int KG[8][2] = {{1,0},{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,-1}};

/* Is square s attacked by side byWhite? */
static int attacked(const Board *b, int s, int byWhite) {
    int r = s / 8, f = s % 8;
    char P = byWhite ? 'P' : 'p', N = byWhite ? 'N' : 'n', B = byWhite ? 'B' : 'b',
         R = byWhite ? 'R' : 'r', Q = byWhite ? 'Q' : 'q', K = byWhite ? 'K' : 'k';
    int pr = byWhite ? r - 1 : r + 1;           /* attacking pawn sits one rank behind */
    if (pr >= 0 && pr < 8) {
        if (f > 0 && b->sq[pr * 8 + f - 1] == P) return 1;
        if (f < 7 && b->sq[pr * 8 + f + 1] == P) return 1;
    }
    for (int i = 0; i < 8; i++) {
        int rr = r + KN[i][0], ff = f + KN[i][1];
        if (rr >= 0 && rr < 8 && ff >= 0 && ff < 8 && b->sq[rr * 8 + ff] == N) return 1;
        rr = r + KG[i][0]; ff = f + KG[i][1];
        if (rr >= 0 && rr < 8 && ff >= 0 && ff < 8 && b->sq[rr * 8 + ff] == K) return 1;
    }
    for (int i = 0; i < 8; i++) {
        int dr = KG[i][0], df = KG[i][1], diag = dr && df;
        int rr = r + dr, ff = f + df;
        while (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) {
            char p = b->sq[rr * 8 + ff];
            if (p) {
                if (p == Q || (diag ? p == B : p == R)) return 1;
                break;
            }
            rr += dr; ff += df;
        }
    }
    return 0;
}

static int king_sq(const Board *b, int white) {
    char K = white ? 'K' : 'k';
    for (int i = 0; i < 64; i++) if (b->sq[i] == K) return i;
    return -1;
}

static int in_check(const Board *b, int white) {
    int k = king_sq(b, white);
    return k >= 0 && attacked(b, k, !white);
}

/* Apply move without legality checks. */
static void make_move(Board *b, Mv m) {
    char p = b->sq[m.from], P = up(p);
    int w = is_white(p);
    int fr = m.from / 8, ff = m.from % 8, tr = m.to / 8, tf = m.to % 8;
    if (P == 'P' && m.to == b->ep && ff != tf && !b->sq[m.to])
        b->sq[fr * 8 + tf] = 0;                         /* en passant capture */
    b->sq[m.to] = p; b->sq[m.from] = 0;
    if (P == 'P' && (tr == 7 || tr == 0)) {
        char q = m.promo ? m.promo : 'Q';
        b->sq[m.to] = w ? q : (char)(q + 32);
    }
    if (P == 'K' && (tf - ff == 2 || ff - tf == 2)) {   /* castling: move the rook too */
        int rf = tf > ff ? 7 : 0, rt = tf > ff ? 5 : 3;
        b->sq[fr * 8 + rt] = b->sq[fr * 8 + rf]; b->sq[fr * 8 + rf] = 0;
    }
    if (P == 'K') b->castle &= w ? ~3 : ~12;
    if (m.from == 0 || m.to == 0) b->castle &= ~2;
    if (m.from == 7 || m.to == 7) b->castle &= ~1;
    if (m.from == 56 || m.to == 56) b->castle &= ~8;
    if (m.from == 63 || m.to == 63) b->castle &= ~4;
    b->ep = (P == 'P' && (tr - fr == 2 || fr - tr == 2)) ? ((fr + tr) / 2) * 8 + ff : -1;
    b->white = !b->white;
}

/* Generate all legal moves for the side to move. Returns count. */
static int gen_legal(const Board *b, Mv *out) {
    Mv ps[256]; int n = 0, w = b->white;
    for (int s = 0; s < 64; s++) {
        char p = b->sq[s];
        if (!p || is_white(p) != w) continue;
        char P = up(p); int r = s / 8, f = s % 8;
        if (P == 'P') {
            int dir = w ? 1 : -1, start = w ? 1 : 6, last = w ? 7 : 0;
            int r1 = r + dir;
            if (r1 >= 0 && r1 < 8) {
                if (!b->sq[r1 * 8 + f]) {
                    if (r1 == last) { const char *pp = "QRBN"; for (int k = 0; k < 4; k++) ps[n++] = (Mv){s, r1 * 8 + f, pp[k]}; }
                    else ps[n++] = (Mv){s, r1 * 8 + f, 0};
                    if (r == start && !b->sq[(r + 2 * dir) * 8 + f]) ps[n++] = (Mv){s, (r + 2 * dir) * 8 + f, 0};
                }
                for (int df = -1; df <= 1; df += 2) {
                    int ff = f + df; if (ff < 0 || ff > 7) continue;
                    int t = r1 * 8 + ff; char q = b->sq[t];
                    if ((q && is_white(q) != w) || t == b->ep) {
                        if (r1 == last) { const char *pp = "QRBN"; for (int k = 0; k < 4; k++) ps[n++] = (Mv){s, t, pp[k]}; }
                        else ps[n++] = (Mv){s, t, 0};
                    }
                }
            }
        } else if (P == 'N' || P == 'K') {
            const int (*d)[2] = P == 'N' ? KN : KG;
            for (int i = 0; i < 8; i++) {
                int rr = r + d[i][0], ff = f + d[i][1];
                if (rr < 0 || rr > 7 || ff < 0 || ff > 7) continue;
                char q = b->sq[rr * 8 + ff];
                if (!q || is_white(q) != w) ps[n++] = (Mv){s, rr * 8 + ff, 0};
            }
            if (P == 'K' && s == (w ? 4 : 60) && !in_check(b, w)) {
                int base = w ? 0 : 56, ks = w ? 1 : 4, qs = w ? 2 : 8;
                if ((b->castle & ks) && !b->sq[base + 5] && !b->sq[base + 6] &&
                    !attacked(b, base + 5, !w) && b->sq[base + 7] == (w ? 'R' : 'r'))
                    ps[n++] = (Mv){s, base + 6, 0};
                if ((b->castle & qs) && !b->sq[base + 3] && !b->sq[base + 2] && !b->sq[base + 1] &&
                    !attacked(b, base + 3, !w) && b->sq[base] == (w ? 'R' : 'r'))
                    ps[n++] = (Mv){s, base + 2, 0};
            }
        } else {
            int i0 = P == 'B' ? 4 : 0, i1 = P == 'R' ? 4 : 8;
            for (int i = i0; i < i1; i++) {
                int rr = r + KG[i][0], ff = f + KG[i][1];
                while (rr >= 0 && rr < 8 && ff >= 0 && ff < 8) {
                    char q = b->sq[rr * 8 + ff];
                    if (!q || is_white(q) != w) ps[n++] = (Mv){s, rr * 8 + ff, 0};
                    if (q) break;
                    rr += KG[i][0]; ff += KG[i][1];
                }
            }
        }
    }
    int m = 0;
    for (int i = 0; i < n; i++) {
        Board c = *b; make_move(&c, ps[i]);
        if (!in_check(&c, w)) out[m++] = ps[i];
    }
    return m;
}

/* Write SAN for move m (must be legal in b) into buf; returns length. */
static int san(const Board *b, Mv m, char *buf) {
    int n = 0; char p = b->sq[m.from], P = up(p);
    int ff = m.from % 8, tf = m.to % 8, tr = m.to / 8;
    if (P == 'K' && (tf - ff == 2 || ff - tf == 2)) {
        const char *c = tf > ff ? "O-O" : "O-O-O";
        while (*c) buf[n++] = *c++;
    } else {
        int capture = b->sq[m.to] != 0 || (P == 'P' && ff != tf);
        if (P == 'P') {
            if (capture) { buf[n++] = (char)('a' + ff); buf[n++] = 'x'; }
        } else {
            buf[n++] = P;
            Mv lm[256]; int k = gen_legal(b, lm), amb = 0, sameF = 0, sameR = 0;
            for (int i = 0; i < k; i++) {
                if (lm[i].to != m.to || lm[i].from == m.from || b->sq[lm[i].from] != p) continue;
                amb = 1;
                if (lm[i].from % 8 == ff) sameF = 1;
                if (lm[i].from / 8 == m.from / 8) sameR = 1;
            }
            if (amb) {
                if (!sameF) buf[n++] = (char)('a' + ff);
                else if (!sameR) buf[n++] = (char)('1' + m.from / 8);
                else { buf[n++] = (char)('a' + ff); buf[n++] = (char)('1' + m.from / 8); }
            }
            if (capture) buf[n++] = 'x';
        }
        buf[n++] = (char)('a' + tf); buf[n++] = (char)('1' + tr);
        if (P == 'P' && (tr == 7 || tr == 0)) { buf[n++] = '='; buf[n++] = m.promo ? m.promo : 'Q'; }
    }
    Board c = *b; make_move(&c, m);
    if (in_check(&c, c.white)) {
        Mv lm[256];
        buf[n++] = gen_legal(&c, lm) ? '+' : '#';
    }
    buf[n] = 0;
    return n;
}

/* Is move m among the legal moves? Fills in promo if needed. */
static int find_legal(const Board *b, Mv *m) {
    Mv lm[256]; int k = gen_legal(b, lm);
    for (int i = 0; i < k; i++)
        if (lm[i].from == m->from && lm[i].to == m->to && (!lm[i].promo || lm[i].promo == (m->promo ? m->promo : 'Q'))) {
            m->promo = lm[i].promo;
            return 1;
        }
    return 0;
}
