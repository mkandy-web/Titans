/* Replacement slc.dll for Chess Titans (64-bit, English build).
 *
 * The original slc.dll in this package is a 2 KB stub that only answers
 * SLGetWindowsInformationDWORD with "1". This DLL keeps that behaviour and,
 * when chess.exe loads it, also:
 *   1. removes the artificial 1-3 second "minimum think time" before every
 *      computer move,
 *   2. adds difficulty level 11 "Crazy Hard" (no evaluation noise, no node
 *      limit, up to CRAZY_SECONDS of search per move),
 *   3. adds "Save Game as PGN..." / "Save Previous Game as PGN..." to the
 *      Game menu (Ctrl+S saves the current game, or the last finished game
 *      if a new one has not started yet).
 * Every patch checks the original bytes first and is skipped if they differ.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <commdlg.h>
#include <shlobj.h>
#include <commctrl.h>
#include "pgn.h"

/* Default search time per move for Crazy Hard. Can be changed with
   ChessMod.ini next to chess.exe:  [CrazyHard]  SecondsPerMove=30  */
#define CRAZY_SECONDS_DEFAULT 30
static double g_crazySeconds = CRAZY_SECONDS_DEFAULT;

/* RVAs inside chess.exe (image base 0x100000000). */
#define RVA_MINTHINK_JBE   0x4ce43   /* jbe -> jmp: skip the sleep loop        */
#define RVA_SETLEVEL       0x3bdb0   /* engine level table function            */
#define RVA_SLIDER_RANGE   0x49ce4   /* mov r9d, 0x90000 (TBM_SETRANGE 0..9)   */
#define RVA_NEWGAME_LEVEL  0x62dc8   /* level bookkeeping in "new game"        */
#define RVA_NEWGAME_RESUME 0x62df0
#define RVA_SAVE_DIFF      0x64738   /* mov eax, [g_level] when saving a game  */
#define RVA_TIMECAP        0x39038   /* double 70.0: hard search time limit    */
#define RVA_STATS_UPDATE   0x6915c
#define RVA_STATS          0x199b90
#define RVA_RESULT         0x199cfc  /* game result code, 0 = none            */
#define RVA_GAME_LEVEL     0x199d00  /* level used for statistics (0..9)       */
#define RVA_PREF_LEVEL     0x199d1c  /* difficulty chosen in Options (0..10)   */
#define RVA_GAME_PTR       0x19f520
#define RVA_COMPUTER_VTBL  0x27940
#define RVA_SLACK_LEVEL    0x1a9f00  /* unused bytes at the end of .data       */
#define GAME_MOVES         0x49c98
#define GAME_MOVECOUNT     0x49ca0

#define ID_SAVE_PGN       0x8030
#define ID_SAVE_PREV_PGN  0x8031

static BYTE *g_base;
static HINSTANCE g_inst;
static int g_activeLevel = -1;
static int g_patched;
static WNDPROC g_origProc;
static HWND g_hwnd;

/* ---------- small helpers (no CRT) ---------- */
static int patch(DWORD rva, const void *expect, const void *bytes, SIZE_T n) {
    BYTE *p = g_base + rva; DWORD old;
    if (expect && memcmp(p, expect, n) != 0) return 0;
    if (!VirtualProtect(p, n, PAGE_EXECUTE_READWRITE, &old)) return 0;
    memcpy(p, bytes, n);
    VirtualProtect(p, n, old, &old);
    FlushInstructionCache(GetCurrentProcess(), p, n);
    return 1;
}

static void set_timecap(double secs) {
    DWORD old; double *p = (double *)(g_base + RVA_TIMECAP);
    if (*p == secs) return;
    if (VirtualProtect(p, 8, PAGE_EXECUTE_READWRITE, &old)) { *p = secs; VirtualProtect(p, 8, old, &old); }
}

/* ---------- engine level table (replaces the function at RVA_SETLEVEL) ---------- */
typedef struct { int nodes, nodes2, noise, book; } Level;
static const Level LEVELS[11] = {
    {      50,    1000, 83,  15 },
    {     120,    2330, 66,  30 },
    {     315,    5428, 51,  45 },
    {     890,   12650, 38,  60 },
    {    2760,   29500, 27,  75 },
    {    9110,   68700, 18,  90 },
    {   32110,  160000, 11, 100 },
    {  120420,  373000,  6, 100 },
    {  478680,  868600,  3, 100 },
    { 2500000, 5000000,  2, 100 },
    /* 11: Crazy Hard. The game multiplies the node limit by up to 1.25,
       so stay below 2^31 / 1.25. Time is the real limit here. */
    { 1600000000, 1600000000, 0, 100 },
};

static void SetEngineLevel(BYTE *engine, int level) {
    if (level == -1) return;
    *(int *)(engine + 0x49b44) = 100;
    if (level < 0 || level > 10) return;
    *(int *)(engine + 0x49b34) = LEVELS[level].nodes;
    *(int *)(engine + 0x49b38) = LEVELS[level].nodes2;
    *(int *)(engine + 0x49b48) = LEVELS[level].noise;
    *(int *)(engine + 0x49b44) = LEVELS[level].book;
    set_timecap(level == 10 ? g_crazySeconds : 70.0);
}

/* ---------- game snapshot for PGN ---------- */
typedef struct {
    TitansMove *moves; int count;
    int whiteComputer, blackComputer, level, result;
    SYSTEMTIME when;
} Snapshot;
static Snapshot g_prev;

/* Fills an empty Snapshot with the game currently on the board. */
static void take_snapshot(Snapshot *s) {
    BYTE *game = *(BYTE **)(g_base + RVA_GAME_PTR);
    s->moves = 0; s->count = 0;
    if (!game) return;
    int n = *(int *)(game + GAME_MOVECOUNT);
    TitansMove *src = *(TitansMove **)(game + GAME_MOVES);
    if (n <= 0 || !src) return;
    if (n > 4000) n = 4000;
    s->moves = (TitansMove *)HeapAlloc(GetProcessHeap(), 0, sizeof(TitansMove) * n);
    if (!s->moves) return;
    memcpy(s->moves, src, sizeof(TitansMove) * n);
    s->count = n;
    void *w = *(void **)(game + 0x40), *b = *(void **)(game + 0x48);
    void *cv = g_base + RVA_COMPUTER_VTBL;
    s->whiteComputer = w && *(void **)w == cv;
    s->blackComputer = b && *(void **)b == cv;
    s->level = g_activeLevel >= 0 ? g_activeLevel : *(int *)(g_base + RVA_GAME_LEVEL);
    s->result = *(int *)(g_base + RVA_RESULT);
    GetLocalTime(&s->when);
}

/* Called from the patched "new game" code. Returns the engine level. */
static int __stdcall NewGameHook(void) {
    int pref = *(int *)(g_base + RVA_PREF_LEVEL);
    if (pref < 0) pref = 0;
    if (pref > 10) pref = 10;
    Snapshot ended;                         /* keep the game that just ended */
    take_snapshot(&ended);
    if (ended.count) {
        if (g_prev.moves) HeapFree(GetProcessHeap(), 0, g_prev.moves);
        g_prev = ended;
    }
    *(int *)(g_base + RVA_RESULT) = 0;      /* same as a fresh start         */
    int statsLevel = pref > 9 ? 9 : pref;   /* stats only have 10 slots      */
    int *gameLevel = (int *)(g_base + RVA_GAME_LEVEL);
    if (*gameLevel != statsLevel) {
        *gameLevel = statsLevel;
        ((void (*)(void *))(g_base + RVA_STATS_UPDATE))(g_base + RVA_STATS);
    }
    g_activeLevel = pref;
    *(int *)(g_base + RVA_SLACK_LEVEL) = pref;
    return pref;
}

/* ---------- PGN export ---------- */
static const char *RESULT_TEXT[11] = {
    "", "White wins by checkmate.", "Black wins by checkmate.", "Black resigns. White wins.",
    "White resigns. Black wins.", "Black runs out of time. White wins.", "White runs out of time. Black wins.",
    "Stalemate, the game is a draw.", "No progress for fifty moves; the game is a draw.",
    "Position repeated three times; the game is a draw.", "Too few pieces left for checkmate; the game is a draw.",
};

static void level_name(int level, char *out) {
    if (level == 10) { s_cat(out, 0, 32, "Crazy Hard"); return; }
    int p = s_cat(out, 0, 32, "Level "); s_num(out, p, 32, level + 1);
}

static void player_name(int computer, int level, int white, char *out) {
    if (computer) {
        int p = s_cat(out, 0, 64, "Chess Titans (");
        char ln[32]; level_name(level, ln);
        p = s_cat(out, p, 64, ln); s_cat(out, p, 64, ")");
        return;
    }
    WCHAR wn[64]; DWORD n = 64;
    if (GetUserNameW(wn, &n) && n > 1) {
        char an[64]; int len = WideCharToMultiByte(CP_UTF8, 0, wn, -1, an, sizeof an, 0, 0);
        if (len > 1) {
            /* Use plain ASCII-safe copy; strip quotes. */
            int j = 0; for (int i = 0; an[i] && j < 63; i++) if (an[i] != '"' && an[i] != '\\') out[j++] = an[i];
            out[j] = 0; if (j) return;
        }
    }
    s_cat(out, 0, 64, white ? "White" : "Black");
}

static void save_pgn(HWND hwnd, int previous) {
    Snapshot cur = {0}, *s;
    if (previous) s = &g_prev;
    else {
        take_snapshot(&cur);
        s = cur.count ? &cur : &g_prev;   /* nothing played yet: offer the last game */
    }
    if (!s->count) {
        MessageBoxW(hwnd, previous ? L"There is no previous game to save yet." : L"No moves have been played yet.",
                    L"Save Game as PGN", MB_OK | MB_ICONINFORMATION);
        goto done;
    }

    PgnInfo info = {0};
    int vsComputer = s->whiteComputer || s->blackComputer;
    player_name(s->whiteComputer, s->level, 1, info.white);
    player_name(s->blackComputer, s->level, 0, info.black);
    if (vsComputer) level_name(s->level, info.difficulty);
    int p = s_num(info.date, 0, 16, s->when.wYear);
    p = s_cat(info.date, p, 16, s->when.wMonth < 10 ? ".0" : "."); p = s_num(info.date, p, 16, s->when.wMonth);
    p = s_cat(info.date, p, 16, s->when.wDay < 10 ? ".0" : "."); s_num(info.date, p, 16, s->when.wDay);
    int r = s->result;
    if (r >= 1 && r <= 10) {
        s_cat(info.result, 0, 8, (r == 1 || r == 3 || r == 5) ? "1-0" : (r == 2 || r == 4 || r == 6) ? "0-1" : "1/2-1/2");
        s_cat(info.termination, 0, sizeof info.termination, RESULT_TEXT[r]);
    }

    int cap = 32768 + s->count * 32;
    char *text = (char *)HeapAlloc(GetProcessHeap(), 0, cap);
    if (!text) goto done;
    int mate, bad;
    int len = build_pgn(s->moves, s->count, &info, text, cap, &mate, &bad);

    WCHAR file[MAX_PATH] = L"", dir[MAX_PATH] = L"";
    wsprintfW(file, L"Chess Titans %04d-%02d-%02d %02d-%02d.pgn", s->when.wYear, s->when.wMonth,
              s->when.wDay, s->when.wHour, s->when.wMinute);
    SHGetFolderPathW(NULL, CSIDL_PERSONAL, NULL, 0, dir);
    OPENFILENAMEW ofn = {0};
    ofn.lStructSize = sizeof ofn;
    ofn.hwndOwner = hwnd;
    ofn.lpstrFilter = L"PGN chess games (*.pgn)\0*.pgn\0All files (*.*)\0*.*\0";
    ofn.lpstrFile = file;
    ofn.nMaxFile = MAX_PATH;
    ofn.lpstrInitialDir = dir[0] ? dir : NULL;
    ofn.lpstrDefExt = L"pgn";
    ofn.lpstrTitle = previous ? L"Save Previous Game as PGN" : L"Save Game as PGN";
    ofn.Flags = OFN_OVERWRITEPROMPT | OFN_PATHMUSTEXIST | OFN_NOCHANGEDIR | OFN_EXPLORER;

    typedef BOOL (WINAPI *GSFN)(LPOPENFILENAMEW);
    HMODULE cd = LoadLibraryW(L"comdlg32.dll");
    GSFN getSave = cd ? (GSFN)GetProcAddress(cd, "GetSaveFileNameW") : NULL;
    if (getSave && getSave(&ofn)) {
        HANDLE h = CreateFileW(file, GENERIC_WRITE, 0, NULL, CREATE_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
        DWORD wr = 0;
        if (h == INVALID_HANDLE_VALUE || !WriteFile(h, text, (DWORD)len, &wr, NULL) || wr != (DWORD)len)
            MessageBoxW(hwnd, L"The PGN file could not be written.", L"Save Game as PGN", MB_OK | MB_ICONERROR);
        if (h != INVALID_HANDLE_VALUE) CloseHandle(h);
    }
    HeapFree(GetProcessHeap(), 0, text);
done:
    if (cur.moves) HeapFree(GetProcessHeap(), 0, cur.moves);
}

/* ---------- menu + window hook ---------- */
static int is_game_menu(HMENU m) {
    int n = GetMenuItemCount(m);
    for (int i = 0; i < n; i++) if (GetMenuItemID(m, i) == 0x8003) return 1;
    return 0;
}

static void ensure_menu_items(HMENU m) {
    if (GetMenuState(m, ID_SAVE_PGN, MF_BYCOMMAND) != (UINT)-1) return;
    /* Insert just before "Exit" (0x800c), in their own separated group. */
    InsertMenuW(m, 0x800c, MF_BYCOMMAND | MF_SEPARATOR, 0, NULL);
    InsertMenuW(m, 0x800c, MF_BYCOMMAND | MF_STRING, ID_SAVE_PGN, L"Save Game as &PGN...\tCtrl+S");
    InsertMenuW(m, 0x800c, MF_BYCOMMAND | MF_STRING, ID_SAVE_PREV_PGN, L"Save Pre&vious Game as PGN...");
    InsertMenuW(m, 0x800c, MF_BYCOMMAND | MF_SEPARATOR, 0, NULL);
}

static void fix_item_type(HMENU m, UINT id) {
    /* The game turns every item into an owner-drawn one; keep ours as plain text. */
    MENUITEMINFOW mi;
    memset(&mi, 0, sizeof mi);
    mi.cbSize = sizeof mi;
    mi.fMask = MIIM_FTYPE;
    if (GetMenuItemInfoW(m, id, FALSE, &mi) && (mi.fType & MFT_OWNERDRAW)) {
        mi.fType &= ~MFT_OWNERDRAW;
        SetMenuItemInfoW(m, id, FALSE, &mi);
    }
}

static LRESULT CALLBACK CallRetHook(int code, WPARAM wp, LPARAM lp);

static LRESULT CALLBACK HookProc(HWND h, UINT msg, WPARAM wp, LPARAM lp) {
    static HHOOK dialogHook;
    /* A hook lives only as long as the thread that installed it, so install it
       here, on the game's UI thread. */
    if (!dialogHook) dialogHook = SetWindowsHookExW(WH_CALLWNDPROCRET, CallRetHook, g_inst, GetCurrentThreadId());
    if (msg == WM_INITMENUPOPUP && is_game_menu((HMENU)wp)) {
        ensure_menu_items((HMENU)wp);
        EnableMenuItem((HMENU)wp, ID_SAVE_PREV_PGN, MF_BYCOMMAND | (g_prev.count ? MF_ENABLED : MF_GRAYED));
        LRESULT r = CallWindowProcW(g_origProc, h, msg, wp, lp);
        fix_item_type((HMENU)wp, ID_SAVE_PGN);
        fix_item_type((HMENU)wp, ID_SAVE_PREV_PGN);
        return r;
    }
    if (msg == WM_COMMAND && HIWORD(wp) == 0 && (LOWORD(wp) == ID_SAVE_PGN || LOWORD(wp) == ID_SAVE_PREV_PGN)) {
        save_pgn(h, LOWORD(wp) == ID_SAVE_PREV_PGN);
        return 0;
    }
    if (msg == WM_KEYDOWN && wp == 'S' && (GetKeyState(VK_CONTROL) & 0x8000) && !(lp & 0x40000000)) {
        save_pgn(h, 0);
        return 0;
    }
    return CallWindowProcW(g_origProc, h, msg, wp, lp);
}

/* ---------- Options dialog: label the 11th slider position ---------- */
#define ID_DIFF_SLIDER 0x406
static const WCHAR PROP_ORIG[] = L"CTModOrigProc", PROP_LABEL[] = L"CTModLabel";

static void update_difficulty_label(HWND dlg) {
    HWND label = (HWND)GetPropW(dlg, PROP_LABEL), tb = GetDlgItem(dlg, ID_DIFF_SLIDER);
    if (!label || !tb) return;
    int pos = (int)SendMessageW(tb, TBM_GETPOS, 0, 0);
    WCHAR t[64];
    if (pos >= 10) lstrcpyW(t, L"Difficulty: Crazy Hard");
    else wsprintfW(t, L"Difficulty: Level %d", pos + 1);
    SetWindowTextW(label, t);
}

static LRESULT CALLBACK OptionsDlgProc(HWND d, UINT msg, WPARAM wp, LPARAM lp) {
    WNDPROC orig = (WNDPROC)GetPropW(d, PROP_ORIG);
    LRESULT r = CallWindowProcW(orig, d, msg, wp, lp);
    if (msg == WM_HSCROLL && (HWND)lp == GetDlgItem(d, ID_DIFF_SLIDER)) update_difficulty_label(d);
    if (msg == WM_NCDESTROY) { RemovePropW(d, PROP_ORIG); RemovePropW(d, PROP_LABEL); }
    return r;
}

static BOOL CALLBACK FixOptionsChild(HWND c, LPARAM lp) {
    WCHAR cls[32], t[32];
    if (!GetClassNameW(c, cls, 32) || lstrcmpiW(cls, L"Static") != 0) return TRUE;
    GetWindowTextW(c, t, 32);
    if (lstrcmpW(t, L"Level 10") == 0) SetWindowTextW(c, L"Crazy Hard");
    if (lstrcmpW(t, L"Difficulty") == 0) {
        HWND dlg = (HWND)lp; RECT rc, dr;
        GetWindowRect(c, &rc); GetClientRect(dlg, &dr);
        MapWindowPoints(NULL, dlg, (POINT *)&rc, 2);
        int right = dr.right - 8;                       /* room for the longer text */
        if (right > rc.right) MoveWindow(c, rc.left, rc.top, right - rc.left, rc.bottom - rc.top, FALSE);
        SetPropW(dlg, PROP_LABEL, c);
    }
    return TRUE;
}

static LRESULT CALLBACK CallRetHook(int code, WPARAM wp, LPARAM lp) {
    if (code == HC_ACTION) {
        CWPRETSTRUCT *c = (CWPRETSTRUCT *)lp;
        if (c->message == WM_INITDIALOG) {
            HWND tb = GetDlgItem(c->hwnd, ID_DIFF_SLIDER); WCHAR cls[32];
            if (tb && GetClassNameW(tb, cls, 32) && lstrcmpiW(cls, L"msctls_trackbar32") == 0 &&
                !GetPropW(c->hwnd, PROP_ORIG)) {
                EnumChildWindows(c->hwnd, FixOptionsChild, (LPARAM)c->hwnd);
                SetPropW(c->hwnd, PROP_ORIG, (HANDLE)GetWindowLongPtrW(c->hwnd, GWLP_WNDPROC));
                SetWindowLongPtrW(c->hwnd, GWLP_WNDPROC, (LONG_PTR)OptionsDlgProc);
                update_difficulty_label(c->hwnd);
            }
        }
    }
    return CallNextHookEx(NULL, code, wp, lp);
}

static BOOL CALLBACK FindOurWindow(HWND h, LPARAM lp) {
    DWORD pid; WCHAR cls[64];
    GetWindowThreadProcessId(h, &pid);
    if (pid == GetCurrentProcessId() && GetClassNameW(h, cls, 64) && lstrcmpW(cls, L"ChessWindowClass") == 0) {
        *(HWND *)lp = h; return FALSE;
    }
    return TRUE;
}

static DWORD WINAPI WatchThread(LPVOID unused) {
    (void)unused;
    for (int i = 0; i < 1200 && !g_hwnd; i++) {   /* up to 2 minutes */
        HWND h = NULL;
        EnumWindows(FindOurWindow, (LPARAM)&h);
        if (h) {
            g_origProc = (WNDPROC)GetWindowLongPtrW(h, GWLP_WNDPROC);
            if (g_origProc) { SetWindowLongPtrW(h, GWLP_WNDPROC, (LONG_PTR)HookProc); g_hwnd = h; }
            break;
        }
        Sleep(100);
    }
    return 0;
}

/* ---------- install ---------- */
static void install(void) {
    g_base = (BYTE *)GetModuleHandleW(NULL);
    /* Make sure this is the expected chess.exe: check the level function bytes. */
    static const BYTE setlevelOrig[] = {0x83,0xfa,0xff,0x0f,0x84,0xc2,0x01,0x00,0x00,0x83,0xfa,0x05,0xc7,0x81};
    if (memcmp(g_base + RVA_SETLEVEL, setlevelOrig, sizeof setlevelOrig) != 0) return;

    /* 1. No minimum think time. */
    static const BYTE jbe[] = {0x76, 0x46}, jmp[] = {0xEB, 0x46};
    patch(RVA_MINTHINK_JBE, jbe, jmp, 2);

    /* 2a. Level function -> SetEngineLevel (jmp [rip+0]; dq addr). */
    BYTE j[14] = {0xFF, 0x25, 0, 0, 0, 0};
    *(UINT64 *)(j + 6) = (UINT64)(ULONG_PTR)&SetEngineLevel;
    if (!patch(RVA_SETLEVEL, setlevelOrig, j, sizeof j)) return;

    /* 2b. Options slider 0..10. */
    static const BYTE rngOrig[] = {0x41,0xB9,0x00,0x00,0x09,0x00}, rngNew[] = {0x41,0xB9,0x00,0x00,0x0A,0x00};
    patch(RVA_SLIDER_RANGE, rngOrig, rngNew, 6);

    /* 2c. New-game level bookkeeping -> NewGameHook (keeps stats at 10 slots). */
    static const BYTE ngOrig[40] = {0x8b,0x15,0x32,0x6f,0x13,0x00,0x8b,0x05,0x48,0x6f,0x13,0x00,0x3b,0xd0,0x74,0x18,
        0x89,0x05,0x22,0x6f,0x13,0x00,0x48,0x8d,0x0d,0xab,0x6d,0x13,0x00,0xe8,0x72,0x63,0x00,0x00,0x8b,0x15,0x10,0x6f,0x13,0x00};
    BYTE ng[40];
    memset(ng, 0x90, sizeof ng);
    ng[0] = 0x48; ng[1] = 0xB8; *(UINT64 *)(ng + 2) = (UINT64)(ULONG_PTR)&NewGameHook;   /* mov rax, hook */
    ng[10] = 0xFF; ng[11] = 0xD0;                                                         /* call rax      */
    ng[12] = 0x89; ng[13] = 0xC2;                                                         /* mov edx, eax  */
    ng[14] = 0xEB; ng[15] = (BYTE)(RVA_NEWGAME_RESUME - (RVA_NEWGAME_LEVEL + 16));        /* jmp resume    */
    patch(RVA_NEWGAME_LEVEL, ngOrig, ng, sizeof ng);

    /* 2d. Saved games remember level 11 too. */
    static const BYTE sdOrig[] = {0x8b,0x05,0xc2,0x55,0x13,0x00};
    BYTE sd[6] = {0x8b, 0x05};
    *(INT32 *)(sd + 2) = (INT32)(RVA_SLACK_LEVEL - (RVA_SAVE_DIFF + 6));
    *(int *)(g_base + RVA_SLACK_LEVEL) = 0;
    patch(RVA_SAVE_DIFF, sdOrig, sd, 6);

    g_patched = 1;
    /* 3. PGN menu. */
    HANDLE t = CreateThread(NULL, 0, WatchThread, NULL, 0, NULL);
    if (t) CloseHandle(t);
}

BOOL WINAPI DllMain(HINSTANCE inst, DWORD reason, LPVOID reserved) {
    (void)reserved;
    if (reason == DLL_PROCESS_ATTACH) {
        DisableThreadLibraryCalls(inst);
        g_inst = inst;
        WCHAR path[MAX_PATH];
        DWORD n = GetModuleFileNameW(NULL, path, MAX_PATH);
        /* Only touch chess.exe. */
        if (n >= 9 && n < MAX_PATH - 8 && lstrcmpiW(path + n - 9, L"chess.exe") == 0) {
            lstrcpyW(path + n - 9, L"ChessMod.ini");
            int secs = (int)GetPrivateProfileIntW(L"CrazyHard", L"SecondsPerMove", CRAZY_SECONDS_DEFAULT, path);
            if (secs < 1) secs = 1;
            if (secs > 600) secs = 600;
            g_crazySeconds = secs;
            install();
        }
    }
    return TRUE;
}

/* The function chess.exe actually imports from slc.dll. Same as the original stub. */
__declspec(dllexport) HRESULT WINAPI SLGetWindowsInformationDWORD(PCWSTR name, DWORD *value) {
    (void)name;
    if (value) *value = 1;
    return S_OK;
}
