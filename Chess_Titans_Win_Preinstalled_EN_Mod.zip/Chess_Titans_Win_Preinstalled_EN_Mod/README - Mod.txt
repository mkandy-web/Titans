Chess Titans - Mod
=================

What's new
----------
1. Faster computer moves
   The original game always waited 1-3 seconds before playing a computer move,
   even when it had already decided. That wait is gone. Levels 1-8 now reply
   in under a second (most of that is the piece animation).
   Levels 9-10 still think for several seconds, because that is real thinking
   time, not waiting; shortening it would make them weaker.

2. Save games as PGN
   Game menu > "Save Game as PGN..."   (or Ctrl+S)
   Game menu > "Save Previous Game as PGN..."
   - "Save Game as PGN" saves the game on the board (finished or not).
   - After a game ends and you click "Play again", use
     "Save Previous Game as PGN" to save the game you just finished.
   Files use standard chess notation (e.g. 1. e4 e5 2. Nf3 Nc6) and work in
   Lichess, Chess.com, ChessBase, SCID, etc. Result, date, players and
   difficulty are filled in.

3. Level 11 "Crazy Hard"
   Game menu > Options > drag the Difficulty slider all the way right.
   Crazy Hard removes the random mistakes the engine makes on purpose at every
   other level (even level 10), has no limit on how many positions it may
   search, and thinks up to 30 seconds per move (about 2-3x level 10).
   Change the thinking time in ChessMod.ini (more seconds = stronger).
   Statistics for Crazy Hard games are counted under Level 10, because the
   game only stores statistics for 10 levels.

Install
-------
Copy slc.dll and ChessMod.ini from the "Game Files" folder into your
Chess Titans folder (for example C:\Program Files\Microsoft Games\Chess),
replacing the existing slc.dll. Windows will ask for administrator permission.
Or just run chess.exe from the "Game Files" folder here.

Uninstall
---------
Put slc_original.dll back as slc.dll and delete ChessMod.ini.

How it works
------------
chess.exe was not modified. The mod lives entirely in slc.dll, which the game
already loads at startup (the original slc.dll in this package was a 2 KB
stand-in for a Windows licensing check; the new one keeps that behaviour).
When the game starts, slc.dll patches a few instructions in memory, after
checking that the original bytes match this exact version of the game.
If they don't match, it leaves the game alone.
Source code is in the "mod-source" folder (build: zig cc -O2 -s -shared
-target x86_64-windows-gnu -o slc.dll slc.c -luser32 -ladvapi32 -lshell32).

Notes
-----
- Crazy Hard is the strongest this 2006 engine can play, but it's an old,
  single-threaded engine (about 200,000-500,000 positions per second), so a
  strong club player can still beat it. A higher SecondsPerMove helps.
- If you later go back to the original slc.dll while Crazy Hard is selected,
  pick another level in Options first.
